from flask import Flask

app = Flask(__name__, template_folder="app/views", static_folder="app/static")
app.config["PROJECT_ROOT"] = app.root_path
app.config["JSON_SORT_KEYS"] = False

from app.controllers.main_controller import main_bp
from app.controllers.admin_controller import admin_bp

app.register_blueprint(main_bp)
app.register_blueprint(admin_bp)

if __name__ == "__main__":
    app.run(debug=True)
