# MarketPredict — MVP MVC
Sistema académico de análisis y predicción de comportamiento de activos financieros.

## Arquitectura
- `models/`: entidades y configuración.
- `services/`: adquisición, validación, procesamiento, análisis, predicción, alertas, informes y almacenamiento.
- `controllers/`: rutas MVC/API.
- `views/`: interfaz web.
- `static/`: CSS y JavaScript.

## Ejecución
1. Instalar Python 3.10+.
2. `pip install -r requirements.txt`
3. `python app.py`
4. Abrir `http://127.0.0.1:5000`

El MVP funciona sin API externa mediante datos demo reproducibles. El adaptador `APIFinanciera` está separado para conectar posteriormente el proveedor elegido sin modificar la interfaz ni el motor de análisis.

## Funcionalidades implementadas
RF01 selección de activo; RF02 obtención/validación de datos; RF03 gráficos e indicadores; RF04 predicción; RF05 secuencia; RF06 alerta; RF07 informe HTML; RF08 registro/histórico; RF09 errores; RF10 configuración técnica.

No ejecuta operaciones financieras reales ni conecta obligatoriamente con brokers.
