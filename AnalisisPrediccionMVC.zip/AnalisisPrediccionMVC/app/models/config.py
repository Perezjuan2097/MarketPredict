from dataclasses import dataclass
import os

@dataclass
class ModelConfig:
    window: int = 20
    horizon: int = 5
    alert_drop: float = 2.0
    model_version: str = "ML-Linear-1.0"

    @classmethod
    def from_env(cls):
        return cls(
            window=int(os.getenv("MODEL_WINDOW", "20")),
            horizon=int(os.getenv("MODEL_HORIZON", "5")),
            alert_drop=float(os.getenv("ALERT_DROP", "2.0")),
            model_version=os.getenv("MODEL_VERSION", "ML-Linear-1.0")
        )
