from flask import Flask
from pathlib import Path

def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "mvp-dev-key"
    app.config["PROJECT_ROOT"] = Path(__file__).resolve().parent.parent
    from app.controllers.main_controller import main_bp
    from app.controllers.admin_controller import admin_bp
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")
    return app
