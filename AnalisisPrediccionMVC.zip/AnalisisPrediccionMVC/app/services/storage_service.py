import json
from pathlib import Path
from datetime import datetime

class Storage:
    def __init__(self, root):
        self.path=Path(root)/"data"/"predicciones.json"
        self.path.parent.mkdir(exist_ok=True)
    def read(self):
        if not self.path.exists(): return []
        try: return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception: return []
    def add(self, registro):
        data=self.read(); data.append(registro); self.path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    def all(self): return list(reversed(self.read()))
