from flask import Blueprint, render_template, request, redirect, url_for
from app.models.config import ModelConfig
import os

admin_bp=Blueprint("admin",__name__)
@admin_bp.get("/")
def panel(): return render_template("admin.html", cfg=ModelConfig.from_env())
@admin_bp.post("/config")
def config():
    os.environ["MODEL_WINDOW"]=request.form.get("window","20")
    os.environ["MODEL_HORIZON"]=request.form.get("horizon","5")
    os.environ["ALERT_DROP"]=request.form.get("alert_drop","2")
    os.environ["MODEL_VERSION"]=request.form.get("version","ML-Linear-1.0")
    return redirect(url_for("admin.panel"))
